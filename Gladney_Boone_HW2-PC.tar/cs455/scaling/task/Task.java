package cs455.scaling.task;

public interface Task {
	public int getTaskType();
}
